const Sequelize = require('sequelize');
const db = require('../database/db.js')


module.exports = db.sequelize.define(
    "product",{
          id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
          },
          code: {  
            type:Sequelize.STRING
          },
          productname: {
              type: Sequelize.STRING
          },
          category_id: {  
            type:Sequelize.INTEGER
          },
          image: {
              type: Sequelize.STRING
          },
          gst: {
            type: Sequelize.STRING
        },
        asncode: {
            type: Sequelize.STRING
        },
        pricemapping: {
          type: Sequelize.JSON
         }
         
    },
    {
        timestamps: false
    }
)
