const Sequelize = require('sequelize');
const db = require('../database/db.js')

// 'use strict'
module.exports = db.sequelize.define(
    "category",{
          id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
          },
          uomcode_id: {  
            type:Sequelize.INTEGER
          },
          categoryname: {
              type: Sequelize.STRING
          },

          // uomlist:(models) =>{
                     
          // }
    },
    {
        timestamps: false
    }
)





// module.exports = (sequelize, DataTypes) => {  




//   const Category = db.sequelize.define(
//     "category",{
//           id: {
//             type: Sequelize.INTEGER,
//             primaryKey: true,
//             autoIncrement: true
//           },
//           uomcode_id: {  
//             // type:Sequelize.INTEGER
//             type:Sequelize.UUID
//           },
//           categoryname: {
//               type: Sequelize.STRING
//           },

//           // uomlist:(models) =>{
                     
//           // }
//     },
//     // {
//     //     timestamps: false
//     // }
// ),


// const Category = db.sequelize.define(
//   "user",{
//     id: {
//       type: Sequelize.INTEGER,
//       primaryKey: true,
//       autoIncrement: true
//   },
//   first_name: {
//       type: Sequelize.STRING
//   },
//   last_name: {
//       type: Sequelize.STRING
//   },
//   email: {
//       type: Sequelize.STRING
//   },
//   password: {
//       type: Sequelize.STRING
//   },
//   created: {
//       type: Sequelize.DATE,
//       defaultValue: Sequelize.NOW
//   }
//   },
//   // {
//   //     timestamps: false
//   // }
// )



// UsersContactsLists.belongsTo(ChannelsTypes, {foreignKey: 'mobile_number'});
// Category.hasMany(Channels, {foreignKey: 'id'});



//   // const Users = sequelize.define('users', {
//   //   id: {
//   //     type: DataTypes.UUID,
//   //     primaryKey: true,
//   //     defaultValue: DataTypes.UUIDV4,
//   //     allowNull: false
//   //   },
//   //   username: {
//   //     type: DataTypes.STRING,
//   //     required: true
//   //   },
//   //   role: {
//   //     type: DataTypes.ENUM,
//   //     values: ['user', 'admin', 'disabled']

//   //   },
//   //   created_at: {
//   //     type: DataTypes.DATE,
//   //     allowNull: false
//   //   },
//   //   updated_at:  DataTypes.DATE,
//   //   deleted_at: DataTypes.DATE
//   // }, {
//   //   underscored: true
//   // });
//   return Category;
// };