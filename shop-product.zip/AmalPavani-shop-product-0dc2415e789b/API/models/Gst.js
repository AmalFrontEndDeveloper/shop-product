const Sequelize = require('sequelize');
const db = require('../database/db.js')


module.exports = db.sequelize.define(
    "gst",{
          id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
          },
          gstcode: {  
            type:Sequelize.STRING
          },
          gstname: {
              type: Sequelize.STRING
          },
    },
    {
        timestamps: false
    }
)
