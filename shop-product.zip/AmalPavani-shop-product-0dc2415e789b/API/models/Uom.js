const Sequelize = require('sequelize');
const db = require('../database/db.js')

module.exports = db.sequelize.define(
    "uom",{
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
          },
          uomcode: {  
            type:Sequelize.STRING
          },
          uomname: {
              type: Sequelize.STRING
          }
    },
    {
        timestamps: false
    }
)
