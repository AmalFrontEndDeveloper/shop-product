const Sequelize = require('sequelize');
const db = require('../database/db.js')


module.exports = db.sequelize.define(
    "task",{
          id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
          },
          task_name: {  
            type:Sequelize.STRING
          },
          task_description: {
              type: Sequelize.STRING
          },
          task_time: {
            type: Sequelize.STRING,
            // type: Sequelize.DATE,
          }
    },
    {
        timestamps: false
    }
)
