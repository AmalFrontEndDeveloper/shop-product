var express = require('express');
var cors = require('cors');
// var mysql = require('mysql');
var bodyParser =  require('body-parser');
var swaggerUi = require('swagger-ui-express');
var swaggerDocument = require('./swagger.json');
const multer = require('multer');
var morgan = require('morgan');
var fs = require('fs');
var path = require('path');

var app = express();
var port = process.env.PORT || 5000;


app.use(bodyParser.json())
app.use(cors())
app.use(
    bodyParser.urlencoded({extended:false})
)
app.use(morgan('dev'));
app.use('/public/uploads',express.static('public/uploads'));

var Users = require("./routes/Users");
app.use("/users", Users)
var tasks = require('./routes/tasks');
app.use('/task', tasks);
var uoms = require('./routes/uoms'); 
app.use('/uom', uoms);
var categoryservice = require('./routes/category');
app.use('/categoryservice', categoryservice);
var Roleservice = require('./routes/roles');
app.use('/roleservice', Roleservice);
var Departmentservice = require('./routes/departments');
app.use('/departmentservice', Departmentservice);
var Productservice = require('./routes/products');
app.use('/productservice', Productservice);
var UsermanagementService = require('./routes/usermanagements');
app.use('/usermanagementService', UsermanagementService);
var brandService = require('./routes/brand');
app.use('/brandService', brandService);
var GstService = require('./routes/gst');
app.use('/gstService', GstService);




app.listen(port);


var accessLogStream = fs.createWriteStream(
    path.join(__dirname, 'access.log'), {flags: 'a'}
);
// setup the logger
app.use(morgan('combined', {stream: accessLogStream}));




// const DIR = '.public/uploads/';
const storage = multer.diskStorage({
    destination:'public/uploads/',
    //     destination: function (req, file, callback) {
    //   callback(null, DIR);
    // },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits:{fileSize:1000000},
    fileFilter: function(req, file, cb){
        checkFileType(file, cb);
    }
}).single('file');


function checkFileType(file, cb){
    const filetypes = /jpeg|jpg|png|gif/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());

    const mimetype = filetypes.test(file.mimetype);

    if(mimetype && extname){
        return cb(null,true);
    }else{
        cb('Error: Images Only!');
    }
}


app.post('/upload',(req,res)=>{
    upload(req,res, (err)=>{
     if(err){
         res.send({ message:err})
     }else{
         console.log(req.file);
if(req.file == undefined){
          res.send({ message:  'No File Selected' });
}else{
    res.send({
         message: 'File Uploaded',
         file: `uploads/${req.file.filename}`

         });
}

     }
    })
});











app.use('/swagger', swaggerUi.serve, swaggerUi.setup(swaggerDocument))

console.log("Server Running On Port: " + port);
