const express = require('express');
var  router = express.Router();
const Role  = require('../models/Role');

router.post('/roledetail', (req,res,next)=>{
    Role.findAll().then(data=>{
        res.json(data);
    })
        .catch(err=>{
            res.send("error :" + err);
        })
});

router.post('/roledetailsingle', (req,res,next)=>{
    Role.findOne({
        where: {
            id: req.body.id
        }
    })
        .then(data=>{
            if(data){
                res.json(data)
            }else
            {
                res.send('Task does not exist')
            }
        })
        .catch(err=>{
            res.send('error :'  + err)
        })
})

router.post('/roleAdd',(req,res)=>{
    const roleData = {
        rolecode : req.body.rolecode ,
        rolename: req.body.rolename
    }
    if(!roleData){
        res.status(400)
        res.json({
            error: 'Bad Data'
        })
    }else{
        Role.create(roleData).then(data=>{
            res.send(data);
        })
            .catch(err =>{
                res.json('error :' + err);
            });
    }
});

router.post('/roleDelete', (req,res)=>{
    Role.destroy({
        where : {
            id:req.body.id
        }
    })
        .then(()=>{
            res.json({ status: 'Role SuccessFully Deleted.....!' })
        })
        .catch(err=>{
            res.send('error: ' + err)
        })
});


router.post('/roleUpdate', (req,res,next)=>{
    let  role_id = req.body.id ;
    let  roleData = req.body ;

    Role.findOne({where: {id: role_id}})
    .then(roleinfo =>{
        roleinfo.update(roleData).then(RoleDatadetail=>{
            res.json(RoleDatadetail);
        })
    })
})
// router.post('/roleUpdate', (req,res,next)=>{
//     const roleData = {
//         rolecode : req.body.rolecode ,
//         rolename: req.body.rolename
//     }
//     if(!roleData){
//         res.json({error:'Bad data'})
//     }else{
//         Role.update(roleData,{
//             Where: {id: req.body.id}
//         })
//             .then(() => {
//                 res.json({ status: 'Category Successfully Updated...!'})
//             })
//             .error(err => handleError(err))
//     }
// })


module.exports = router ;
