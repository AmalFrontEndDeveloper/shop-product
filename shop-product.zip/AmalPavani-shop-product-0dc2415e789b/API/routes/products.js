const express = require('express');
var  router = express.Router();
const ProductDModel  = require('../models/Product');
const CategoryModel  = require('../models/Category.js');


CategoryModel.hasMany(ProductDModel, {foreignKey: 'category_id'});
ProductDModel.belongsTo(CategoryModel, {foreignKey: 'category_id'})

router.post('/productDetail', (req,res,next)=>{
    ProductDModel.findAll({
        include: [
          {
              model:CategoryModel,
              required: true
          }
          ],
          group: ['product.productname']
        }).then((items)=>{
              res.send(items);
           }).catch(function (err) {
              res.send(err);
        });
});

// router.post('/productDetail', (req,res,next)=>{
//     ProductDModel.findAll().then(data=>{
//         res.json(data);
//     })
//         .catch(err=>{
//             res.send("error :" + err);
//         })
// });

router.post('/productsingle', (req,res,next)=>{
    ProductDModel.findOne({
        where: {
            id: req.body.id
        }
    })
        .then(data=>{
            if(data){
                res.json(data)
            }else
            {
                res.send('Product does not exist')
            }
        })
        .catch(err=>{
            res.send('error :'  + err)
        })
})

router.post('/productAdd',(req,res)=>{
    const productData = {
        code : req.body.code,
        productname: req.body.productname,
        category_id : req.body.category_id,
        image: req.body.image,
        gst : req.body.gst,
        asncode: req.body.asncode,
        pricemapping: req.body.pricemapping,
         
    }
    if(!productData){
        res.status(400)
        res.json({
            error: 'Bad Data'
        })
    }else{
        ProductDModel.create(productData).then(data=>{
            res.send(data);
        })
            .catch(err =>{
                res.json('error :' + err);
            });
    }
});

router.post('/productDelete', (req,res)=>{
    ProductDModel.destroy({
        where : {
            id:req.body.id
        }
    })
        .then(()=>{
            res.json({ status: 'Product SuccessFully Deleted.....!' })
        })
        .catch(err=>{
            res.send('error: ' + err)
        })
});

// router.post('/productUpdate', (req,res,next)=>{
//     const productData = {
//         code : req.body.code,
//         productname: req.body.productname,
//         category_id : req.body.category_id,
//         image: req.body.image,
//         gst : req.body.gst,
//         asncode: req.body.asncode
//     }
//     if(!productData){
//         res.json({error:'Bad data'})
//     }else{
//         ProductDModel.update(productData,{
//             Where: {id: req.body.id}
//         })
//             .then(() => {
//                 res.json({ status: 'Product Successfully Updated...!'})
//             })
//             .error(err => handleError(err))
//     }
// })

router.post('/productUpdate', (req,res,next)=>{
    let  product_id = req.body.id ;
    let  ProductData = req.body ;

    ProductDModel.findOne({where: {id: product_id}})
    .then(productinfo =>{
        productinfo.update(ProductData).then(ProductDatadetail=>{
            res.json(ProductDatadetail);
        })
    })
})
module.exports = router ;
