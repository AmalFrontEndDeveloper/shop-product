const express = require('express');
var  router = express.Router();
const usermgtModel  = require('../models/Usermanagement');
const roleModel  = require('../models/Role');
const deptModel  = require('../models/Department');

roleModel.hasMany(usermgtModel, {foreignKey: 'role_id'});
usermgtModel.belongsTo(roleModel, {foreignKey: 'role_id'})

deptModel.hasMany(usermgtModel, {foreignKey: 'department_id'});
usermgtModel.belongsTo(deptModel, {foreignKey: 'department_id'})

router.post('/usermanagementDetail', (req,res,next)=>{
    usermgtModel.findAll({
        include: [
          {
              model:roleModel,
              required: true
          },
          {
            model:deptModel,
            required: true
        }
          ],
          group: ['usermanagement.name']
        }).then((items)=>{
              res.send(items);
           }).catch(function (err) {
              res.send(err);
        });
});

router.post('/usermanagementsingle', (req,res,next)=>{
    usermgtModel.findOne({
        where: {
            id: req.body.id
        }
    })
        .then(data=>{
            if(data){
                res.json(data)
            }else
            {
                res.send('Product does not exist')
            }
        })
        .catch(err=>{
            res.send('error :'  + err)
        })
})

router.post('/usermanagementAdd',(req,res)=>{
    const usermanagementData = {
        username : req.body.username,
        password: req.body.password,
        name : req.body.name,
        role_id: req.body.role_id,
        department_id : req.body.department_id,
        image: req.body.image
    }
    if(!usermanagementData){
        res.status(400)
        res.json({
            error: 'Bad Data'
        })
    }else{
        usermgtModel.create(usermanagementData).then(data=>{
            res.send(data);
        })
            .catch(err =>{
                res.json('error :' + err);
            });
    }
});

router.post('/usermanagementDelete', (req,res)=>{
    usermgtModel.destroy({
        where : {
            id:req.body.id
        }
    })
        .then(()=>{
            res.json({ status: 'Product SuccessFully Deleted.....!' })
        })
        .catch(err=>{
            res.send('error: ' + err)
        })
});


router.post('/usermanagementUpdate', (req,res,next)=>{
    let  usermanage_id = req.body.id ;
    let  UserManageData = req.body ;

    usermgtModel.findOne({where: {id: usermanage_id}})
    .then(usermanageinfo =>{
        usermanageinfo.update(UserManageData).then(UserManageDatadetail=>{
            res.json(UserManageDatadetail);
        })
    })
})



// router.post('/usermanagementUpdate', (req,res,next)=>{
//     const usermanagementData = {
//         username : req.body.username,
//         password: req.body.password,
//         name : req.body.name,
//         role_id: req.body.role_id,
//         department_id : req.body.department_id,
//         image: req.body.image
//     }
//     if(!usermanagementData){
//         res.json({error:'Bad data'})
//     }else{
//         usermgtModel.update(usermanagementData,{
//             Where: {id: req.body.id}
//         })
//             .then(() => {
//                 res.json({ status: 'Product Successfully Updated...!'})
//             })
//             .error(err => handleError(err))
//     }
// })


module.exports = router ;
