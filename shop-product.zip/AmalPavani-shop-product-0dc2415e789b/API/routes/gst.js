const express = require('express');
var  router = express.Router();
const GstModel  = require('../models/Gst.js');


router.post('/gstDetail', (req,res,next)=>{
    GstModel.findAll().then(data=>{
        res.json(data);
    })
        .catch(err=>{
            res.send("error :" + err);
        })
});

router.post('/single_gst', (req,res,next)=>{
    GstModel.findOne({
        where: {
            id: req.body.id
        }
    })
        .then(data=>{
            if(data){
                res.json(data)
            }else
            {
                res.send('Brand does not exist')
            }
        })
        .catch(err=>{
            res.send('error :'  + err)
        })
})

router.post('/GstAdd',(req,res)=>{
    const BrandData = {
        gstcode : req.body.gstcode ,
        gstname: req.body.gstname
    }
    if(!BrandData){
        res.status(400)
        res.json({
            error: 'Bad Data'
        })
    }else{
        GstModel.create(BrandData).then(data=>{
            res.send({
                Message:'Brand Created SuccessFully...!', 
                Result:data, 
            });
        })
            .catch(err =>{
                res.json('error :' + err);
            });
    }
});

router.post('/GstDelete', (req,res)=>{
    GstModel.destroy({
        where : {
            id:req.body.id
        }
    })
        .then(()=>{
            res.json({ status: 'Brand SuccessFully Deleted.....!' })
        })
        .catch(err=>{
            res.send('error: ' + err)
        })
});

router.post('/GstUpdate', (req,res,next)=>{
    let  gst_id = req.body.id ;
    let  gstData = req.body ;

    GstModel.findOne({where: {id: gst_id}})
    .then(gstinfo =>{
        gstinfo.update(gstData).then(GstDatadetail=>{
            res.json(GstDatadetail);
        })
    })
})
module.exports = router ;
