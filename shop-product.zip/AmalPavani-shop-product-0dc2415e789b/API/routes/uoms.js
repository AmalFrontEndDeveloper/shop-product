const express = require('express');
var  router = express.Router();
const Uom  = require('../models/Uom');

router.post('/UomDetail', (req,res,next)=>{
    Uom.findAll().then(data=>{
        res.json(data);
    })
        .catch(err=>{
            res.send("error :" + err);
        })
});

router.post('/productsingle', (req,res,next)=>{
    Uom.findOne({
        where: {
            id: req.body.id
        }
    })
        .then(data=>{
            if(data){
                res.json(data)
            }else
            {
                res.send('UOM does not exist')
            }
        })
        .catch(err=>{
            res.send('error :'  + err)
        })
})

router.post('/UomAdd',(req,res)=>{
const uomData = {
    uomcode : req.body.uomcode,
    uomname : req.body.uomname,
}
  if(!uomData){
     res.status(400)
     res.json({
         error: 'Bad Data'
     })
  }else{
       Uom.create(uomData).then(data=>{
           res.send(data);
       })
       .catch(err=>{
           res.json('error' + err);
       });
  }  
})
router.post('/UomDelete', (req,res)=>{
    Uom.destroy({
        where : {
            id:req.body.id
        }
    })
        .then(()=>{
            res.json({ status: 'UOM SuccessFully Deleted.....!' })
        })
        .catch(err=>{
            res.send('error: ' + err)
        })
});

router.post('/UomUpdate', (req,res,next)=>{
    let  uomId = req.body.id ;
    let  uomData = req.body ;

    Uom.findOne({where: {id: uomId}})
    .then(uominfo =>{
        uominfo.update(uomData).then(uomdatadetail=>{
            res.json(uomdatadetail);
        })
    })

    // const uomData = {
    //     uomcode : req.body.uomcode,
    //     uomname : req.body.uomname,
    // }
    // if(!uomData){
    //     res.json({error:'Bad data'})
    // }else{
    //     ProductDModel.update(uomData,{
    //         Where: {id: req.body.id}
    //     })
    //         .then(() => {
    //             res.json({ status: 'UOM Successfully Updated...!'})
    //         })
    //         .error(err => handleError(err))
    // }
})



module.exports = router ;