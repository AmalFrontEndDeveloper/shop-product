const express = require('express');
var  router = express.Router();
const Task  = require('../models/Task');

router.get('/tasks', (req,res,next)=>{
    Task.findAll().then(tasks=>{
        res.json(tasks);
    })
        .catch(err=>{
            res.send("error :" + err);
        })
});

router.get('/taskscount', (req,res,next)=>{
    Task.count().then(tasks=>{
        res.json(tasks);
    })
        .catch(err=>{
            res.send("error :" + err);
        })
});

router.get('/tasks/:id', (req,res,next)=>{
    Task.findOne({
        where: {
            id: req.params.id
        }
    })
        .then(data=>{
            if(data){
                res.json(data)
            }else
            {
                res.send('Task does not exist')
            }
        })
        .catch(err=>{
            res.send('error :'  + err)
        })
})

router.post('/tasks',(req,res)=>{
    const taskData = {
        task_name : req.body.task_name ,
        task_description: req.body.task_description,
        task_time: req.body.task_time
    }
    if(!taskData){
        res.status(400)
        res.json({
            error: 'Bad Data'
        })
    }else{
        Task.create(taskData).then(data=>{
            res.send(data);
        })
            .catch(err =>{
                res.json('error :' + err);
            });
    }
});

router.delete('/tasks/:id', (req,res)=>{
    Task.destroy({
        where : {
            id:req.params.id
        }
    })
        .then(()=>{
            res.json({ status: 'Task Deleted!' })
        })
        .catch(err=>{
            res.send('error: ' + err)
        })
});

router.put('tasks/:id', (req,res,next)=>{
    const taskData = {
        task_name : req.body.task_name ,
        task_description: req.body.task_description,
        task_time: req.body.task_time
    }
    if(!taskData){
        res.json({error:'Bad data'})
    }else{
        Task.update(taskData,{
            Where: {id: req.params.id}
        })
            .then(() => {
                res.json({ status: 'Task Updated...!'})
            })
            .error(err => handleError(err))
    }
})

// router.post('/upload',(req,res)=>{
//     upload(req,res, (err)=>{
//      if(err){
//          res.send({ message:err})
//      }else{
//          console.log(req.file);
// if(req.file == undefined){
//           res.send({ message:  'No File Selected' });
// }else{
//     res.send({
//          message: 'File Uploaded',
//          file: `uploads/${req.file.filename}`

//          });
// }

//      }
//     })
// });


module.exports = router ;
