const express = require('express');
var  router = express.Router();
const Dept  = require('../models/Department');

router.post('/departmentDetail', (req,res,next)=>{
    Dept.findAll().then(data=>{
        res.json(data);
    })
        .catch(err=>{
            res.send("error :" + err);
        })
});

router.post('/departmentsingle', (req,res,next)=>{
    Dept.findOne({
        where: {
            id: req.body.id
        }
    })
        .then(data=>{
            if(data){
                res.json(data)
            }else
            {
                res.send('Task does not exist')
            }
        })
        .catch(err=>{
            res.send('error :'  + err)
        })
})

router.post('/DepartmentAdd',(req,res)=>{
    const deptData = {
        deptcode : req.body.deptcode ,
        deptname: req.body.deptname
    }
    if(!deptData){
        res.status(400)
        res.json({
            error: 'Bad Data'
        })
    }else{
        Dept.create(deptData).then(data=>{
            res.send({
                Message:'Department Created SuccessFully...!', 
                Result:data, 
            });
        })
            .catch(err =>{
                res.json('error :' + err);
            });
    }
});

router.post('/DepartmentDelete', (req,res)=>{
    Dept.destroy({
        where : {
            id:req.body.id
        }
    })
        .then(()=>{
            res.json({ status: 'Role SuccessFully Deleted.....!' })
        })
        .catch(err=>{
            res.send('error: ' + err)
        })
});

router.post('/DepartmentUpdate', (req,res,next)=>{
    let  dept_id = req.body.id ;
    let  deptData = req.body ;

    Dept.findOne({where: {id: dept_id}})
    .then(deptinfo =>{
        deptinfo.update(deptData).then(DeptDatadetail=>{
            res.json(DeptDatadetail);
        })
    })
})


module.exports = router ;
