const express = require('express');
var  router = express.Router();
const Category  = require('../models/Category.js');
const uommodel  = require('../models/Uom.js');


uommodel.hasMany(Category,{
    foreignKey: {
        fieldName: 'uomcode_id'
    }
});  
// uommodel.hasMany(Category, {foreignKey: 'uomcode_id'});
Category.belongsTo(uommodel, {
    foreignKey: 'uomcode_id'
})
// Category.hasMany(uommodel,{
//     foreignKey: {
//         fieldName: 'id'
//     }
// }); 



// Category.hasMany(uommodel) ; 
router.post('/category', (req,res,next)=>{
    // uommodel.findAll({
    //     include: [
    //       {
    //           model:Category,
    //           attributes: [
    //               ['categoryname', 'categoryname'],
    //               ['uomcode_id', 'uomcode_id'],
    //               ['id', 'categoryid'],     
    //         ]                                      
    //       }
    //       ],
    //           group: ['uom.id']
    //     }).then((items)=>{
    //           res.send(items);
    //        }).catch(function (err) {
    //           res.send(err);
    //     });

    Category.findAll({
        include: [
          {
              model:uommodel,
              required: true
            //   attributes: [['uomcode', 'uomcode',]]                                      
          }
          ],
              group: ['category.categoryname']
        }).then((items)=>{
              res.send(items);
           }).catch(function (err) {
              res.send(err);
        });



    // Category.findAll({
    //    include: [
    //        {
    //         model: uommodel
    //        }
    //    ]
    // }).then(category=>{
    //     res.json({
    //         name: category.categoryname,
    //         uomcode: category.uomcode_id.map(uomcodes=>{
    //             res.json({
    //                 uomcod: uomcodes.uomname
    //             });
    //         }),
    //     });
    // })
    //     .catch(err=>{
    //         res.send("error :" + err);
    //     })
});

router.post('/categoryDetail', (req,res,next)=>{
    Category.findOne({
        where: {
            id: req.body.id
        }
    })
        .then(data=>{
            if(data){
                res.json(data)
            }else
            {
                res.send('Task does not exist')
            }
        })
        .catch(err=>{
            res.send('error :'  + err)
        })
})

router.post('/categoryadd',(req,res)=>{
    const categoryData = {
        uomcode_id : req.body.uomcode_id ,
        categoryname: req.body.categoryname,
    }
    if(!categoryData){
        res.status(400)
        res.json({
            error: 'Bad Data'
        })
    }else{
        Category.create(categoryData).then(data=>{
            res.send(data);
        })
            .catch(err =>{
                res.json('error :' + err);
            });
    }
});

router.post('/categoryDelete', (req,res)=>{
    Category.destroy({
        where : {
            id:req.body.id
        }
    })
        .then(()=>{
            res.json({ status: 'Category SuccessFully Deleted.....!' })
        })
        .catch(err=>{
            res.send('error: ' + err)
        })
});


router.post('/categoryUpdate', (req,res,next)=>{
    let  uomcode_id = req.body.id ;
    let  categoryData = req.body ;

    Category.findOne({where: {id: uomcode_id}})
    .then(categoryinfo =>{
        categoryinfo.update(categoryData).then(categoryDatadetail=>{
            res.json(categoryDatadetail);
        })
    })
})

// router.post('/categoryUpdate', (req,res,next)=>{
//     const categoryData = {
//         uomcode_id : req.body.uomcode_id ,
//         categoryname: req.body.categoryname,
//     }
//     if(!categoryData){
//         res.json({error:'Bad data'})
//     }else{
//         Category.update(categoryData,{
//             Where: {id: req.body.id}
//         })
//             .then(() => {
//                 res.json({ status: 'Category Successfully Updated...!'})
//             })
//             .error(err => handleError(err))
//     }
// })


module.exports = router ;
