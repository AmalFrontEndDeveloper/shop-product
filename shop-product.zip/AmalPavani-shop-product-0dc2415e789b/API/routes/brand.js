const express = require('express');
var  router = express.Router();
const BrandModel  = require('../models/Brand.js');


router.post('/brandDetail', (req,res,next)=>{
    BrandModel.findAll().then(data=>{
        res.json(data);
    })
        .catch(err=>{
            res.send("error :" + err);
        })
});

router.post('/single_brand', (req,res,next)=>{
    BrandModel.findOne({
        where: {
            id: req.body.id
        }
    })
        .then(data=>{
            if(data){
                res.json(data)
            }else
            {
                res.send('Brand does not exist')
            }
        })
        .catch(err=>{
            res.send('error :'  + err)
        })
})

router.post('/BrandAdd',(req,res)=>{
    const BrandData = {
        brandcode : req.body.brandcode ,
        brandname: req.body.brandname
    }
    if(!BrandData){
        res.status(400)
        res.json({
            error: 'Bad Data'
        })
    }else{
        BrandModel.create(BrandData).then(data=>{
            res.send({
                Message:'Brand Created SuccessFully...!', 
                Result:data, 
            });
        })
            .catch(err =>{
                res.json('error :' + err);
            });
    }
});

router.post('/BrandDelete', (req,res)=>{
    BrandModel.destroy({
        where : {
            id:req.body.id
        }
    })
        .then(()=>{
            res.json({ status: 'Brand SuccessFully Deleted.....!' })
        })
        .catch(err=>{
            res.send('error: ' + err)
        })
});

router.post('/BrandUpdate', (req,res,next)=>{
    let  brand_id = req.body.id ;
    let  brandData = req.body ;

    BrandModel.findOne({where: {id: brand_id}})
    .then(brandinfo =>{
        brandinfo.update(brandData).then(BrandDatadetail=>{
            res.json(BrandDatadetail);
        })
    })
})
module.exports = router ;
