import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { UserService } from '../user.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  email: any;
  pass: any;
  isLoginError: boolean = false;
  status: any;
  errormessage: any;
  public logo = 'logo.png'
  constructor(public router:Router,
    public userservice:UserService
    ) { }
  ngOnInit() {
  }
  LoginClick(){
    this.userservice.loginApi(this.email,this.pass).pipe(first()).subscribe((res:any)=>{
      this.status = res;
      console.log(this.status);
      // if(this.status){
        this.router.navigate(['/dashboard']);
      // }
      // else{
      // Swal.fire({
      //   position: 'top-end',
      //   type: 'success',
      //   title: 'Invalid User Name and Password',
      //   showConfirmButton: false,
      //   timer: 1500
      // })
      // }
    },err=>{
      console.log(err.error);
    Swal.fire({
        // position: 'top-end',
        type: 'error',
        title: 'Oops...',
        text: 'Invalid User Name and Password!',
        // showConfirmButton: false,
        // timer: 1500
      })
    })
  }

  registerClick(){
    this.router.navigate(['/register']);
  }
}
