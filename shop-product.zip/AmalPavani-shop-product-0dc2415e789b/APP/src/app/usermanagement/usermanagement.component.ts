import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { Router } from '@angular/router';
import { environment} from '../../environments/environment';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-usermanagement',
  templateUrl: './usermanagement.component.html',
  styleUrls: ['./usermanagement.component.scss']
})
export class UsermanagementComponent implements OnInit {
  adduomform:FormGroup
  teachernames: any;
  environment: any;
  displayedColumns: string[] = ['image','username','password','name','rolename','deptname','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  usermanagelist: any;
  uomDetail: MatTableDataSource<unknown>;
  usermanage_id: any;

  uomdatalist: any;
  uomupdate_id: any;
  uomcodeid: any;
  update_true = false;
  rolelist: any;
  usermanageDetail: MatTableDataSource<unknown>;
  deptlist: any;
  fileupload: File;
  usermanageprofile: any;
  usermanagepic=[];
  usermanagedatalist: any;
  username: any;
  password: any;
  name: any;
  userrole: any;
  deptlist_id: any;
  role_id: any;
  department_id: any;
  usermanageidcodeid: any;
  usermanageid: any;
  photo: any;
  constructor(public _userservice:UserService,public router:Router) { }
  ngOnInit() {
    this.environment=environment;
    this.adduomform = new FormGroup({
      username: new FormControl('',[Validators.required]),
      password: new FormControl('',[Validators.required]),
      name: new FormControl('',[Validators.required]),
      role_id: new FormControl('',[Validators.required]),
      department_id: new FormControl('',[Validators.required]),
    })
this.UserManageList();
this.RoleList();
this.DeptList();
  }
  addUserManageClick(){
    console.log(this.adduomform.value.uomcode);
    console.log();
    this._userservice.UsermanagementAdd(
      this.adduomform.value.username,
      this.adduomform.value.password,
      this.adduomform.value.name,
      this.adduomform.value.role_id,
      this.adduomform.value.department_id,
      this.usermanagepic[0]
      ).pipe(first()).subscribe((res:any)=>{
      console.log(res);
      this.adduomform = new FormGroup({
        username: new FormControl(''),
        password: new FormControl(''),
        name: new FormControl(''),
        role_id: new FormControl(''),
        department_id: new FormControl(''),
      })
      this.UserManageList();
      Swal.fire({
        position: 'top-end',
        type: 'success',
        title: 'Role Added SuccessFully...!',
        showConfirmButton: false,
        timer: 1500
      })
    });
  }
  UserManageList(){
  this._userservice.UsermanagementDetail().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.usermanagelist = res ;
    this.usermanageDetail =  new MatTableDataSource (this.usermanagelist);
    console.log(this.usermanageDetail);
    this.usermanageDetail.paginator = this.paginator;
    this.usermanageDetail.sort = this.sort;
  });
}
RoleList(){
  this._userservice.RoleDetail().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.rolelist = res ;
    console.log(this.rolelist);
  });
}
DeptList(){
  this._userservice.DepartmentDetail().pipe(first()).subscribe((res:any)=>{
    this.deptlist = res ;
    console.log(res);
  });
}
imageupload(file: FileList) {
  this.fileupload =file.item(0);
  console.log(this.fileupload);
  this._userservice.uploadImg(this.fileupload).pipe(first()).subscribe((res)=>{
    console.log(res);
    this.usermanageprofile = res;
    this.usermanagepic.push(this.usermanageprofile.file);
    console.log(this.usermanagepic);
  });
}
UomDetailClick(signledata){
console.log(signledata);
this.router.navigate(['/uomdetail',signledata]);
}
UserManageDeleteClick(data){
  this.usermanage_id = data;
  Swal.fire({
    title: 'Are you sure?',
    text: 'You will not be able to recover this imaginary file!',
    type: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    cancelButtonText: 'No, keep it'
  }).then((result) => {
    if (result.value) {
      Swal.fire(
        'Deleted!',
        'Your imaginary file has been deleted.',
        'success'
      )
      this._userservice.UsermanagementDelete(this.usermanage_id).pipe(first()).subscribe((res:any)=>{
         console.log(res);
         this.UserManageList();
      })

    } else if (result.dismiss === Swal.DismissReason.cancel) {
      Swal.fire(
        'Cancelled',
        'Your imaginary file is safe :)',
        'error'
      )
    }
  })

}
UserManageEditClick(usermanagedata){
  this.usermanagedatalist = usermanagedata;
  console.log(this.usermanagedatalist);
   this.usermanageid= this.usermanagedatalist.id;
   this.username = this.usermanagedatalist.username;
   this.password = this.usermanagedatalist.password;
   this.name = this.usermanagedatalist.name;
   this.role_id = this.usermanagedatalist.role_id;
   this.department_id = this.usermanagedatalist.department_id;
   this.photo = this.usermanagedatalist.image;
   this.update_true = true;
  }
  UpdateusermanageClick(usermanageid){
    console.log(usermanageid)
    this.usermanageid = usermanageid ;
  this._userservice.UsermanagementUpdate(this.usermanageid,this.username,this.password,this.name,this.role_id,this.department_id,this.photo).pipe(first()).subscribe((res:any)=>{
    console.log(res);
    Swal.fire({
      position: 'top-end',
      type: 'success',
      title: 'Role Updated SuccessFully...!',
      showConfirmButton: false,
      timer: 1500
    })
    this.adduomform = new FormGroup({
      username: new FormControl(''),
      password: new FormControl(''),
      name: new FormControl(''),
      role_id: new FormControl(''),
      department_id: new FormControl(''),
    })
    this.UserManageList();
    this.update_true = false;
 })
  }
}
