import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-usermanagementdetail',
  templateUrl: './usermanagementdetail.component.html',
  styleUrls: ['./usermanagementdetail.component.scss']
})
export class UsermanagementdetailComponent implements OnInit {
  uomdetail: any;

  constructor( public route: ActivatedRoute) {
    this.route.params.subscribe( data => this.uomdetail = data)
   }

  ngOnInit() {
  }

}
