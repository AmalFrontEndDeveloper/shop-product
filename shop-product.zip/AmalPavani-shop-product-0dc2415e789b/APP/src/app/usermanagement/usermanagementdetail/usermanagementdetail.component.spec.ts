import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsermanagementdetailComponent } from './usermanagementdetail.component';

describe('UsermanagementdetailComponent', () => {
  let component: UsermanagementdetailComponent;
  let fixture: ComponentFixture<UsermanagementdetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsermanagementdetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsermanagementdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
