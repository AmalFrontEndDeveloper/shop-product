import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-categorydetail',
  templateUrl: './categorydetail.component.html',
  styleUrls: ['./categorydetail.component.scss']
})
export class CategorydetailComponent implements OnInit {
  uomdetail: any;

  constructor( public route: ActivatedRoute) {
    this.route.params.subscribe( data => this.uomdetail = data)
   }

  ngOnInit() {
  }

}
