import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent implements OnInit {
  addCategoryform:FormGroup
  teachernames: any;
  environment: any;
  displayedColumns: string[] = ['uomcode','categoryname','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  uomlist: any;
  uomDetail: MatTableDataSource<unknown>;
  category_id: any;
  uomcode_id: string;
  categoryname: string;
  categorylist: any;
  categoryinfo: MatTableDataSource<unknown>;
  categoryupdate_id: any;
  categorylistData: any;
  update_true = false;
  constructor(public _userservice:UserService) { }
  ngOnInit() {
    this.addCategoryform = new FormGroup({
      uomcode_id: new FormControl('',[Validators.required]),
      categoryname: new FormControl('',[Validators.required]),
    })
this.UomList();
this.CategoryDetails();
  }

  addCategoryClick(){
    console.log(this.addCategoryform.value.uomcode_id);
    this._userservice.CategoryAdd(this.addCategoryform.value.uomcode_id,this.addCategoryform.value.categoryname).pipe(first()).subscribe((res:any)=>{
      console.log(res);
      // this.uomcode_id = '';
      // this.categoryname = '';
      this.addCategoryform = new FormGroup({
        uomcode_id: new FormControl(''),
        categoryname: new FormControl(''),
      })
      this.CategoryDetails();
      Swal.fire({
        position: 'top-end',
        type: 'success',
        title: 'Category Added SuccessFully...!',
        showConfirmButton: false,
        timer: 1500
      })

    });
  }
UomList(){
  this._userservice.UomDetail().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.uomlist = res ;
  });
}
CategoryDeleteClick(data){
  this.category_id = data;
  const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: 'btn btn-success',
    cancelButton: 'btn btn-danger'
  },
  buttonsStyling: false
})

swalWithBootstrapButtons.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonText: 'Yes, delete it!',
  cancelButtonText: 'No, cancel!',
  reverseButtons: true
}).then((result) => {
  if (result.value) {
    swalWithBootstrapButtons.fire(
      'Deleted!',
      'Your file has been deleted.',
      'success'
    )
    this._userservice.CategoryDelete(this.category_id).pipe(first()).subscribe((res:any)=>{
      console.log(res);
      this.CategoryDetails();
   })

  } else if (
    result.dismiss === Swal.DismissReason.cancel
  ) {
    swalWithBootstrapButtons.fire(
      'Cancelled',
      'Your imaginary file is safe :)',
      'error'
    )
  }
})

}
CategoryDetails(){
  this._userservice.CategoryDetails().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.categorylist = res ;
    this.categoryinfo =  new MatTableDataSource (this.categorylist);
    console.log(this.categoryinfo);
    this.categoryinfo.paginator = this.paginator;
    this.categoryinfo.sort = this.sort;
  });
}

CategoryEditClick(categorylist){
  this.categorylistData = categorylist;
  console.log(this.categorylistData);
   this.categoryupdate_id = this.categorylistData.id;
   this.uomcode_id = this.categorylistData.uomcode_id;
   this.categoryname = this.categorylistData.categoryname;
   this.update_true = true;
  }
CategoryUpdateClick(categorylist){
  console.log(categorylist)
  this.categoryupdate_id = categorylist ;
this._userservice.CategoryUpdate(this.categoryupdate_id,this.uomcode_id,this.categoryname).pipe(first()).subscribe((res:any)=>{
  console.log(res);
  this.CategoryDetails();
  this.update_true = false;
  // this.uomcode_id = '';
  // this.categoryname = '';
  this.addCategoryform = new FormGroup({
    uomcode_id: new FormControl(''),
    categoryname: new FormControl(''),
  })
  Swal.fire({
    position: 'top-end',
    type: 'success',
    title: 'Category Updated SuccessFully...!',
    showConfirmButton: false,
    timer: 1500
  })
})
}
}
