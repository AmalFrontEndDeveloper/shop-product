import {Component, OnInit, ViewChild, Inject} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { environment} from '../../environments/environment';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {
  animal: string;
  name: string;
  adduomform:FormGroup
  teachernames: any;
  environment: any;
  displayedColumns: string[] = ['image','code','productname','categoryname','asncode','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  productlist: any;
  productDetail: MatTableDataSource<unknown>;
  product_id: any;
  productdatalist: any;
  productupdate_id: any;
  update_true = false;
  pricelist: any;
  priceinfo: any;
  brand: any;
  mrp: any;
  sellingprice: any;
  supplieprice: any;
  uom: any;
  supplier: any;
  pricinglist:any; 
  priceData=[];
  productcode: string;
  productname: string;
  gst: string;
  asncode: string;
  category: string;
  categorylist: any;
  fileupload: File;
  usermanageprofile: any;
  usermanagepic=[];
  code: any;
  category_id: any;
  productimage: any;
  productid: any;
  constructor( public _userservice:UserService,public router:Router,
    ) { }
  ngOnInit() {
    this.environment=environment;
    this.adduomform = new FormGroup({
      productcode: new FormControl('',[Validators.required]),
      productname: new FormControl('',[Validators.required]),
      category: new FormControl('',[Validators.required]),
      gst: new FormControl('',[Validators.required]),
      asncode: new FormControl('',[Validators.required]),
    })
this.ProductList();
// this.addpricing();
this.CategoryDetails();
// localStorage.setItem('session',JSON.stringify(this.priceData));
  }
  addProductClick(){
    console.log(this.adduomform.value.uomcode);
    console.log(); 
    this.priceinfo = JSON.parse(localStorage.getItem('session'));
console.log(this.priceinfo);
    this._userservice.ProductAdd(
      this.adduomform.value.productcode,
      this.adduomform.value.productname,
      this.adduomform.value.category,
      this.adduomform.value.gst,
      this.adduomform.value.asncode,
      this.usermanagepic[0],
      this.priceinfo
      ).pipe(first()).subscribe((res:any)=>{
      console.log(res);
      localStorage.removeItem('session');
      this.productcode = '';
      this.productname = '';
      this.category = '';
      this.gst = '';
      this.asncode = '';
      this.adduomform = new FormGroup({
        productcode: new FormControl(''),
        productname: new FormControl(''),
        category: new FormControl(''),
        gst: new FormControl(''),
        asncode:new FormControl(''),
      })
      this.priceinfo = [''];
      // this.pricedetails();
      this.ProductList();
      Swal.fire({
        position: 'top-end',
        type: 'success',
        title: 'Product Added SuccessFully...!',
        showConfirmButton: false,
        timer: 1500
      })
    });
  }
ProductList(){
  this._userservice.ProductDetail().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.productlist = res ;
    this.productDetail =  new MatTableDataSource (this.productlist);
    console.log(this.productDetail);
    this.productDetail.paginator = this.paginator;
    this.productDetail.sort = this.sort;
  });
}
CategoryDetails(){
  this._userservice.CategoryDetails().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.categorylist = res ;
  });
}
UomDetailClick(signledata){
console.log(signledata);
this.router.navigate(['/uomdetail',signledata]);
}
ProductDeleteClick(data){
  this.product_id = data;
  Swal.fire({
    title: 'Are you sure?',
    text: 'You will not be able to recover this imaginary file!',
    type: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    cancelButtonText: 'No, keep it'
  }).then((result) => {
    if (result.value) {
      Swal.fire(
        'Deleted!',
        'Your imaginary file has been deleted.',
        'success'
      )
      this._userservice.ProductDelete(this.product_id).pipe(first()).subscribe((res:any)=>{
         console.log(res);
         this.ProductList();
      })
    } else if (result.dismiss === Swal.DismissReason.cancel) {
      Swal.fire(
        'Cancelled',
        'Your imaginary file is safe :)',
        'error'
      )
    }
  })

}
ProductEditClick(productdata){
  console.log(productdata);
  this.productdatalist = productdata;
   this.productcode = this.productdatalist.code;
   this.productname = this.productdatalist.productname;
   this.category = this.productdatalist.category_id;
   this.productimage = this.productdatalist.image;
   this.gst = this.productdatalist.gst;
   this.asncode = this.productdatalist.asncode;
   this.update_true = true;
  }
  UpdateProductClick(productid){
    console.log(productid)
    this.productupdate_id = productid ;
  this._userservice.ProductUpdate(this.productupdate_id,this.productcode,this.productname,this.category,this.productimage,this.gst,this.asncode).pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.ProductList();
    this.update_true = false;
    this.adduomform = new FormGroup({
      productcode: new FormControl(''),
      productname: new FormControl(''),
      category: new FormControl(''),
      gst: new FormControl(''),
      asncode:new FormControl(''),
    })
    Swal.fire({
      position: 'top-end',
      type: 'success',
      title: 'Product Updated SuccessFully...!',
      showConfirmButton: false,
      timer: 1500
    })
 })
  }
  addpricing(){
    this.pricinglist = {
          brand:this.brand,
          mrp:this.mrp,
          sellingprice:this.sellingprice,
          supplieprice:this.supplieprice,
          uom:this.uom,
          supplier:this.supplier
         }
     this.priceData.push(this.pricinglist);
     localStorage.setItem('session',JSON.stringify(this.priceData));
     this.pricedetails();
     this.brand='';
      this.mrp='';
      this.sellingprice='';
      this.supplieprice='';
      this.uom='';
      this.supplier='';
      
  }
pricedetails(){
  this.priceinfo = JSON.parse(localStorage.getItem('session'));
console.log(this.priceinfo);
}
imageupload(file: FileList) {
  this.fileupload =file.item(0);
  console.log(this.fileupload);
  this._userservice.uploadImg(this.fileupload).pipe(first()).subscribe((res)=>{
    console.log(res);
    this.usermanageprofile = res;
    this.usermanagepic.push(this.usermanageprofile.file);
    console.log(this.usermanagepic);
  });
}
}
