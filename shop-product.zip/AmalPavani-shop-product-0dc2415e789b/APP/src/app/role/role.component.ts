import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.scss']
})
export class RoleComponent implements OnInit {
  adduomform:FormGroup
  teachernames: any;
  environment: any;
  displayedColumns: string[] = ['rolecode','rolename','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  uomlist: any;
  roleDetail: MatTableDataSource<unknown>;
  role_id: any;
  rolecode: any;
  rolename: any;
  rolelist: any;
  uomupdate_id: any;
  uomcodeid: any;
  update_true = false;
  role_update_id: any;
  constructor(public _userservice:UserService,public router:Router) { }
  ngOnInit() {
    this.adduomform = new FormGroup({
      rolecode: new FormControl('',[Validators.required]),
      rolename: new FormControl('',[Validators.required]),
    })
this.RoleList();
  }

  addUomClick(){
    console.log(this.adduomform.value.rolecode);
    console.log(this.adduomform.value.rolename);
    this._userservice.RoleAdd(this.adduomform.value.rolecode,this.adduomform.value.rolename).pipe(first()).subscribe((res:any)=>{
      console.log(res);
      // this.rolecode = '';
      // this.rolename = '';

      this.adduomform = new FormGroup({
        rolecode: new FormControl(''),
        rolename: new FormControl(''),
      })
      this.RoleList();
      Swal.fire({
        position: 'top-end',
        type: 'success',
        title: 'Role Added SuccessFully...!',
        showConfirmButton: false,
        timer: 1500
      })
    });
  }
RoleList(){
  this._userservice.RoleDetail().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.rolelist = res ;
    this.roleDetail =  new MatTableDataSource (this.rolelist);
    console.log(this.roleDetail);
    this.roleDetail.paginator = this.paginator;
    this.roleDetail.sort = this.sort;
  });
}
UomDetailClick(signledata){
console.log(signledata);
this.router.navigate(['/uomdetail',signledata]);
}
RoleDeleteClick(data){
  this.role_id = data;
  Swal.fire({
    title: 'Are you sure?',
    text: 'You will not be able to recover this imaginary file!',
    type: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    cancelButtonText: 'No, keep it'
  }).then((result) => {
    if (result.value) {
      Swal.fire(
        'Deleted!',
        'Your imaginary file has been deleted.',
        'success'
      )
      
      this._userservice.RoleDelete(this.role_id).pipe(first()).subscribe((res:any)=>{
         console.log(res);
         this.RoleList();
      })

    } else if (result.dismiss === Swal.DismissReason.cancel) {
      Swal.fire(
        'Cancelled',
        'Your imaginary file is safe :)',
        'error'
      )
    }
  })

}
RoleEditClick(uomdata){
  console.log(uomdata);
  this.rolelist = uomdata;
  //  this.rolelist = this.rolelist.id;
   this.rolecode = this.rolelist.rolecode;
   this.rolename = this.rolelist.rolename;
   this.update_true = true;
  }
  UpdateRoleClick(role_id){
    console.log(role_id)
    this.role_update_id = role_id ;
  this._userservice.RoleUpdate(this.role_update_id,this.rolecode,this.rolename).pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.RoleList();
    this.update_true = false;
    // this.rolename = '';
    // this.rolecode = '';
    this.adduomform = new FormGroup({
      rolecode: new FormControl(''),
      rolename: new FormControl(''),
    })
    this.RoleList();
    Swal.fire({
      position: 'top-end',
      type: 'success',
      title: 'Role Updated SuccessFully...!',
      showConfirmButton: false,
      timer: 1500
    })
 })
  }

}
