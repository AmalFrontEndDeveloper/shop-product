import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-roledetail',
  templateUrl: './roledetail.component.html',
  styleUrls: ['./roledetail.component.scss']
})
export class RoledetailComponent implements OnInit {
  uomdetail: any;

  constructor( public route: ActivatedRoute) {
    this.route.params.subscribe( data => this.uomdetail = data)
   }

  ngOnInit() {
  }

}
