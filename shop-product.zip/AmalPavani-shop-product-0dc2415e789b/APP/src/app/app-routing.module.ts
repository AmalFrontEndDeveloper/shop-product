import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RegisterComponent } from './register/register.component';
import { UomComponent } from './uom/uom.component';
import { CategoryComponent } from './category/category.component';
import { BrandComponent } from './brand/brand.component';
import { DepartmentComponent } from './department/department.component';
import { UsermanagementComponent } from './usermanagement/usermanagement.component';
import { RoleComponent } from './role/role.component';
import { ProductComponent } from './product/product.component';
import { UomdetailComponent } from './uom/uomdetail/uomdetail.component';
import { CategorydetailComponent } from './category/categorydetail/categorydetail.component';
import { BranddetailComponent } from './brand/branddetail/branddetail.component';
import { DepartmentdetailComponent } from './department/departmentdetail/departmentdetail.component';
import { UsermanagementdetailComponent } from './usermanagement/usermanagementdetail/usermanagementdetail.component';
import { RoledetailComponent } from './role/roledetail/roledetail.component';
import { ProductdetailComponent } from './product/productdetail/productdetail.component';
import { GstComponent } from './gst/gst.component';
import { PaymentComponent } from './payment/payment.component';
import { PurchaseOrderDetailComponent } from './purchaseOrder/purchase-order-detail/purchase-order-detail.component';
import { ProfileComponent } from './profile/profile.component';

const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'login',component:LoginComponent},
  {path:'dashboard',component:DashboardComponent},
  {path:'register',component:RegisterComponent},
  {path:'uom',component:UomComponent},
  {path:'uomdetail',component:UomdetailComponent},
  {path:'category',component:CategoryComponent},
  {path:'categorydetail',component:CategorydetailComponent},
  {path:'brand',component:BrandComponent},
  {path:'branddetail',component:BranddetailComponent},
  {path:'department',component:DepartmentComponent},
  {path:'departmentdetail',component:DepartmentdetailComponent},
  {path:'usermanagement',component:UsermanagementComponent},
  {path:'usermanagementdetail',component:UsermanagementdetailComponent},
  {path:'roledetail',component:RoledetailComponent},
  {path:'role',component:RoleComponent},
  {path:'product',component:ProductComponent},
  {path:'productdetail',component:ProductdetailComponent},
  {path:'gst',component:GstComponent},
  {path:'payment',component:PaymentComponent},
  {path:'purchaseOrder',component:PurchaseOrderDetailComponent},
  {path:'profile',component:ProfileComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
