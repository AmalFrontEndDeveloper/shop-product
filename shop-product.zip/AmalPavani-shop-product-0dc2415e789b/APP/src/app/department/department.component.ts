import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.scss']
})
export class DepartmentComponent implements OnInit {
  addDeparmentform:FormGroup
  teachernames: any;
  environment: any;
  displayedColumns: string[] = ['deptcode','deptname','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  deptlist: any;
  DeptDetail: MatTableDataSource<unknown>;
  dept_id: any;
  deptcode: any;
  deptname: any;
  deptdatalist: any;
  deptupdate_id: any;
  uomcodeid: any;
  update_true = false;
  constructor(public _userservice:UserService,public router:Router) { }
  ngOnInit() {
    this.addDeparmentform = new FormGroup({
      deptcode: new FormControl('',[Validators.required]),
      deptname: new FormControl('',[Validators.required]),
    })
this.DeptList();
  }

  DepartmentAddClick(){
    console.log(this.addDeparmentform.value.uomcode);
    console.log();
    this._userservice.DepartmentAdd(this.addDeparmentform.value.deptcode,this.addDeparmentform.value.deptname).pipe(first()).subscribe((res:any)=>{
      console.log(res);
      this.deptcode = '';
      this.deptname = '';
      this.addDeparmentform = new FormGroup({
        deptcode: new FormControl(''),
        deptname: new FormControl(''),
      })
      this.DeptList();
      Swal.fire({
        position: 'top-end',
        type: 'success',
        title: 'Department Added SuccessFully...!',
        showConfirmButton: false,
        timer: 1500
      })
    });
  }
  DeptList(){
  this._userservice.DepartmentDetail().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.deptlist = res ;
    this.DeptDetail =  new MatTableDataSource (this.deptlist);
    console.log(this.DeptDetail);
    this.DeptDetail.paginator = this.paginator;
    this.DeptDetail.sort = this.sort;
  });
}
UomDetailClick(signledata){
console.log(signledata);
this.router.navigate(['/uomdetail',signledata]);
}
DeptDeleteClick(data){
  this.dept_id = data;
  Swal.fire({
    title: 'Are you sure?',
    text: 'You will not be able to recover this imaginary file!',
    type: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    cancelButtonText: 'No, keep it'
  }).then((result) => {
    if (result.value) {
      Swal.fire(
        'Deleted!',
        'Your imaginary file has been deleted.',
        'success'
      )
      this._userservice.DepartmentDelete(this.dept_id).pipe(first()).subscribe((res:any)=>{
         console.log(res);
         this.DeptList();
      })

    } else if (result.dismiss === Swal.DismissReason.cancel) {
      Swal.fire(
        'Cancelled',
        'Your imaginary file is safe :)',
        'error'
      )
    }
  })
}
DeptEditClick(deptdata){
  console.log(deptdata);
  this.deptdatalist = deptdata;
  //  this.uomcodeid = this.deptdatalist.id;
   this.deptcode = this.deptdatalist.deptcode;
   this.deptname = this.deptdatalist.deptname;
   this.update_true = true;
  }
  UpdateDeptClick(deptData){
    console.log(deptData)
    this.deptupdate_id = deptData ;
  this._userservice.DepartmentUpdate(this.deptupdate_id,this.deptcode,this.deptname).pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.DeptList();
    this.update_true = false;
    this.deptcode = '';
    this.deptname = '';
    this.addDeparmentform = new FormGroup({
      deptcode: new FormControl(''),
      deptname: new FormControl(''),
    })
    Swal.fire({
      position: 'top-end',
      type: 'success',
      title: 'Department Updated SuccessFully...!',
      showConfirmButton: false,
      timer: 1500
    })
 })
  }
}
