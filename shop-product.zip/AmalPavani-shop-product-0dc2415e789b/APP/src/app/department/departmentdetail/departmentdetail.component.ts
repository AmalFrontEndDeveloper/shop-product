import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-departmentdetail',
  templateUrl: './departmentdetail.component.html',
  styleUrls: ['./departmentdetail.component.scss']
})
export class DepartmentdetailComponent implements OnInit {
  uomdetail: any;

  constructor( public route: ActivatedRoute) {
    this.route.params.subscribe( data => this.uomdetail = data)
   }
  ngOnInit() {
  }

}
