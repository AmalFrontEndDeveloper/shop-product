import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  taskcount: any;

  constructor(public router:Router,public _userService:UserService) { }

  ngOnInit() {
    this._userService.TaskCount().pipe(first()).subscribe((res:any)=>{
      this.taskcount = res;
    });
  }

}
