import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { UserService } from '../user.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  pass: any;
  isLoginError: boolean = false;
  status: any;
  errormessage: any;
  public logo = 'logo.png'
  firstname: any;
  lastname: any;
  email: any;
  constructor(public router:Router,
    public userservice:UserService
    ) { }
  ngOnInit() {
  }
  RegisterClick(){
    this.userservice.RegisterApi(this.firstname,this.lastname,this.email,this.pass).pipe(first()).subscribe((res:any)=>{
      this.status = res;
      console.log(this.status);
      this.router.navigate(['/login']);
    })
  }
  LoginClick(){
    this.router.navigate(['/login']);
  }

}
