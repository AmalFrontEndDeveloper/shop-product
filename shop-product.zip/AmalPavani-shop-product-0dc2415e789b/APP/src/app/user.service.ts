import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private router:Router,
              public http:HttpClient
  ) { }
  loginApi(email,password){
    return this.http.post(`${environment.apiUrl}users/login`,{email:email,password:password});
  }
  RegisterApi(first_name,last_name,email,password){
    return this.http.post(`${environment.apiUrl}users/register`,{first_name:first_name,last_name:last_name,email:email,password:password});
  }
  TaskCount(){
    return this.http.get(`${environment.apiUrl}task/taskscount`,{});
  }
  UomAddAPI(uomcode,uomname){
    return this.http.post(`${environment.apiUrl}uom/UomAdd`,{uomcode:uomcode,uomname:uomname})
  }
UomDetail(){
  return this.http.post(`${environment.apiUrl}uom/UomDetail`,{});
}
UomDelete(id){
  return this.http.post(`${environment.apiUrl}uom/UomDelete`,{id:id});
}
UomUpdate(id,uomcode,uomname){
  return this.http.post(`${environment.apiUrl}uom/UomUpdate`,{id:id,uomcode:uomcode,uomname:uomname});
}
CategoryAdd(uomcode_id,categoryname){
  return this.http.post(`${environment.apiUrl}categoryservice/categoryadd`,{uomcode_id:uomcode_id,categoryname:categoryname});
}
CategoryDetails(){
  return this.http.post(`${environment.apiUrl}categoryservice/category`,{});
}
CategoryDelete(id){
  return this.http.post(`${environment.apiUrl}categoryservice/categoryDelete`,{id:id});
}

CategoryUpdate(id,uomcode_id,categoryname){
  return this.http.post(`${environment.apiUrl}categoryservice/categoryUpdate`,{id:id,uomcode_id:uomcode_id,categoryname:categoryname});
}
ProductAdd(code,productname,category_id,gst,asncode,image,pricemapping){
  return this.http.post(`${environment.apiUrl}productservice/productAdd`,{code:code,productname:productname,category_id:category_id,gst:gst,asncode:asncode,image:image,pricemapping:pricemapping});
}
ProductDetail(){
  return this.http.post(`${environment.apiUrl}productservice/productDetail`,{});
}
ProductDelete(id){
  return this.http.post(`${environment.apiUrl}productservice/productDelete`,{id:id});
}
ProductUpdate(id,code,productname,category_id,image,gst,asncode){
  return this.http.post(`${environment.apiUrl}productservice/productUpdate`,{id:id,code:code,productname:productname,category_id:category_id,image:image,gst:gst,asncode:asncode});
}
UsermanagementAdd(username,password,name,role_id,department_id,image){
  return this.http.post(`${environment.apiUrl}usermanagementService/usermanagementAdd`,{username:username,password:password,name:name,role_id:role_id,department_id:department_id,image:image});
}
UsermanagementDetail(){
  return this.http.post(`${environment.apiUrl}usermanagementService/usermanagementDetail`,{});
}
UsermanagementDelete(id){
  return this.http.post(`${environment.apiUrl}usermanagementService/usermanagementDelete`,{id:id});
}
UsermanagementUpdate(id,username,password,name,role_id,department_id,image){
  return this.http.post(`${environment.apiUrl}usermanagementService/usermanagementUpdate`,{id:id,username:username,password:password,name:name,role_id:role_id,department_id:department_id,image:image});
}
RoleAdd(rolecode,rolename){
  return this.http.post(`${environment.apiUrl}roleservice/roleAdd`,{rolecode:rolecode,rolename:rolename});
}
RoleDetail(){
  return this.http.post(`${environment.apiUrl}roleservice/roledetail`,{});
}
RoleDelete(id){
  return this.http.post(`${environment.apiUrl}roleservice/roleDelete`,{id:id});
}
RoleUpdate(id,rolecode,rolename){
  return this.http.post(`${environment.apiUrl}roleservice/roleUpdate`,{id:id,rolecode:rolecode,rolename:rolename});
}
DepartmentAdd(deptcode,deptname){
  return this.http.post(`${environment.apiUrl}departmentservice/DepartmentAdd`,{deptcode:deptcode,deptname:deptname});
}
DepartmentDetail(){
  return this.http.post(`${environment.apiUrl}departmentservice/departmentDetail`,{});
}
DepartmentDelete(id){
  return this.http.post(`${environment.apiUrl}departmentservice/DepartmentDelete`,{id:id});
}
DepartmentUpdate(id,deptcode,deptname){
  return this.http.post(`${environment.apiUrl}departmentservice/DepartmentUpdate`,{id:id,deptcode:deptcode,deptname:deptname});
}

uploadImg(file:File){
  const endpoint = environment.apiUrl+'upload';
  const formData: FormData = new FormData();
  formData.append('file', file);
  // formData.append('userid', userid);
  return this.http.post(endpoint, formData);
  // return this.http.post(`${environment.apiUrl}upload`,{});
}
}
