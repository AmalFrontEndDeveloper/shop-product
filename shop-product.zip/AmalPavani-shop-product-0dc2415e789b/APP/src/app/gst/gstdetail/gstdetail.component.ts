import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gstdetail',
  templateUrl: './gstdetail.component.html',
  styleUrls: ['./gstdetail.component.scss']
})
export class GstdetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
