import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { Router } from '@angular/router';
// import Swal from 'sweetalert2';
@Component({
  selector: 'app-brand',
  templateUrl: './brand.component.html',
  styleUrls: ['./brand.component.scss']
})
export class BrandComponent implements OnInit {
  adduomform:FormGroup
  teachernames: any;
  environment: any;
  displayedColumns: string[] = ['uomcode','uomname','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  uomlist: any;
  uomDetail: MatTableDataSource<unknown>;
  uom_id: any;
  uomcode: any;
  uomname: any;
  uomdatalist: any;
  uomupdate_id: any;
  uomcodeid: any;
  update_true = false;
  constructor(public _userservice:UserService,public router:Router) { }
  ngOnInit() {
    this.adduomform = new FormGroup({
      uomcode: new FormControl('',[Validators.required]),
      uomname: new FormControl('',[Validators.required]),
    })
this.UomList();
  }

  addUomClick(){
    console.log(this.adduomform.value.uomcode);
    console.log();
    this._userservice.UomAddAPI(this.adduomform.value.uomcode,this.adduomform.value.uomname).pipe(first()).subscribe((res:any)=>{
      console.log(res);
      this.uomcode = '';
      this.uomname = '';
      this.UomList();
    });
  }
UomList(){
  this._userservice.UomDetail().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.uomlist = res ;
    this.uomDetail =  new MatTableDataSource (this.uomlist);
    console.log(this.uomDetail);
    this.uomDetail.paginator = this.paginator;
    this.uomDetail.sort = this.sort;
  });
}
UomDetailClick(signledata){
console.log(signledata);
this.router.navigate(['/uomdetail',signledata]);
}
UomDeleteClick(data){
  this.uom_id = data;
  // Swal.fire({
  //   title: 'Are you sure?',
  //   text: 'You will not be able to recover this imaginary file!',
  //   type: 'warning',
  //   showCancelButton: true,
  //   confirmButtonText: 'Yes, delete it!',
  //   cancelButtonText: 'No, keep it'
  // }).then((result) => {
  //   if (result.value) {
  //     Swal.fire(
  //       'Deleted!',
  //       'Your imaginary file has been deleted.',
  //       'success'
  //     )
      
      this._userservice.UomDelete(this.uom_id).pipe(first()).subscribe((res:any)=>{
         console.log(res);
         this.UomList();
      })

  //   } else if (result.dismiss === Swal.DismissReason.cancel) {
  //     Swal.fire(
  //       'Cancelled',
  //       'Your imaginary file is safe :)',
  //       'error'
  //     )
  //   }
  // })

}
UomEditClick(uomdata){
  console.log(uomdata);
  this.uomdatalist = uomdata;
   this.uomcodeid = this.uomdatalist.id;
   this.uomcode = this.uomdatalist.uomcode;
   this.uomname = this.uomdatalist.uomname;
   this.update_true = true;
  }
  UpdateUomClick(uomid){
    console.log(uomid)
    this.uomupdate_id = uomid ;
  this._userservice.UomUpdate(this.uomupdate_id,this.uomcode,this.uomname).pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.UomList();
    this.update_true = false;
 })
  }
}
