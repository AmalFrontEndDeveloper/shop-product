import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-branddetail',
  templateUrl: './branddetail.component.html',
  styleUrls: ['./branddetail.component.scss']
})
export class BranddetailComponent implements OnInit {
  uomdetail: any;

  constructor( public route: ActivatedRoute) {
    this.route.params.subscribe( data => this.uomdetail = data)
   }
  ngOnInit() {
  }

}
